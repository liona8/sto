<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include('connection.php');

// Connect to the database using mysqli
// $connect = mysqli_connect($RDS_URL, $RDS_user, $RDS_pwd, $RDS_DB);
// if (!$connect) {
//     die("Connection failed: " . mysqli_connect_error());
// }
?>
<!DOCTYPE html>
<html>
  <head>
    <title>Add New Movie</title>
    <link href="design.css" type="text/css" rel="stylesheet">
  </head>

  <body>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="jumbotron">
                    <div id="wrapper">
                        <div id="left">
                            <?php include("menu1.php"); ?>
                        </div>
                        
                        <div id="right">
                            <h2>Details of Movie</h2>
                            <?php
                            if (isset($_GET['view'])) {
                                $movid = $_GET["movid"];

                                // Prepare the SQL statement to prevent SQL injection
                                $stmt = $connect->prepare("SELECT * FROM movie WHERE movie_id = ?");
                                $stmt->bind_param("i", $movid);
                                $stmt->execute();
                                $result = $stmt->get_result();
                                $row = $result->fetch_assoc();

                                if ($row) {
                                    echo "<br><b>ID</b><br>";
                                    echo $row["movie_id"]; 
                                    echo "<br><br><b>Title</b><br>";
                                    echo $row["movie_title"];
                                    echo "<br><br><b>Ticket Price</b><br>";
                                    echo "RM ".number_format($row["movie_ticket_price"], 2); 
                                    echo "<br><br><b>Summary</b><br>";
                                    echo $row["movie_summary"]; 
                                    echo "<br><br><b>Release Date</b><br>";
                                    echo $row["movie_release_date"]; 
                                    echo "<br><br>";
                                } else {
                                    echo "No movie found with that ID.";
                                }

                                $stmt->close();
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/scripts.js"></script>
    </body>
</html>

<?php
$connect->close();
?>
