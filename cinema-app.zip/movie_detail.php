<?php

include('rds.conf.php');
include('connection.php');


?>
<!DOCTYPE html>
<html>
<head>
    <title>Movie Detail</title>
    <link href="design.css" type="text/css" rel="stylesheet" />
</head>
<body>
    <?php include('menu1.php'); ?>
    <div id="wrapper">
        <div id="left">
            <?php include("menu1.php"); ?>
        </div>
        
        <div id="right">
            <h1>Details of Movie</h1>
            <?php
            if (isset($_GET['view'])) {
                $movid = $_GET["movid"];

                // Prepare the SQL statement to prevent SQL injection
                $stmt = $connect->prepare("SELECT * FROM movie WHERE movie_id = ?");
                $stmt->bind_param("i", $movid);
                $stmt->execute();
                $result = $stmt->get_result();
                $row = $result->fetch_assoc();

                if ($row) {
                    echo "<br><b>ID</b><br>";
                    echo $row["movie_id"]; 
                    echo "<br><br><b>Title</b><br>";
                    echo $row["movie_title"];
                    echo "<br><br><b>Ticket Price</b><br>";
                    echo "RM ".number_format($row["movie_ticket_price"], 2); 
                    echo "<br><br><b>Summary</b><br>";
                    echo $row["movie_summary"]; 
                    echo "<br><br><b>Release Date</b><br>";
                    echo $row["movie_release_date"]; 
                    echo "<br><br>";
                } else {
                    echo "No movie found with that ID.";
                }

                $stmt->close();
            }
            ?>
        </div>
    </div>
</body>
</html>

<?php
$connect->close();
?>
