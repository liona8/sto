<?php

echo "<p><a href='movie_add.php'>Add Movie</a></p>";
// echo "<p><a href='movie_list(view_details).php'>Movie List (with details only)</a></p>";
// echo "<p><a href='movie_list(edit).php'>Movie List(with edit)</a></p>";
echo "<p><a href='index.php'>Movie List</a></p>";


?>