<?php

include('rds.conf.php');
include('connection.php');
?>
<!DOCTYPE html>
<html>
<head>
    <title>Add New Movie</title>
    <link href="design.css" type="text/css" rel="stylesheet" />
</head>
<body> 
    <?php include('menu1.php'); ?>
    <div id="wrapper">
        <div id="left">
            <?php include("menu1.php"); ?>
        </div>
        
        <div id="right">
            <h1>Insert New Movie</h1>
            <form name="addfrm" method="post" action="">
                <p><label>Title:</label><input type="text" name="mov_title" size="80"></p>
                <p><label>Ticket Price:</label><input type="text" name="mov_price" size="10"></p>
                <p><label>Summary:</label><textarea cols="60" rows="4" name="mov_summary"></textarea></p>
                <p><label>Release Date:</label><input type="date" name="mov_release"></p>
                <p><input type="submit" name="savebtn" value="SAVE MOVIE"></p>
            </form>
        </div>
    </div>
</body>
</html>

<?php
if(isset($_POST["savebtn"])) {
    $mtitle = $_POST["mov_title"];      
    $mprice = $_POST["mov_price"];      
    $msummary = $_POST["mov_summary"];      
    $mrelease = $_POST["mov_release"];      

    $stmt = $connect->prepare("INSERT INTO movie (movie_title, movie_ticket_price, movie_summary, movie_release_date) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $mtitle, $mprice, $msummary, $mrelease);
    
    if ($stmt->execute()) {
        echo '<script type="text/javascript">alert("' . $mtitle . ' saved.");</script>';
    } else {
        echo '<script type="text/javascript">alert("Error saving movie: ' . $stmt->error . '");</script>';
    }
    $stmt->close();
}

$connect->close();
?>
