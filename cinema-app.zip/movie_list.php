<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include('connection.php');

// Connect to the database using mysqli
// $connect = mysqli_connect($RDS_URL, $RDS_user, $RDS_pwd, $RDS_DB);
// if (!$connect) {
//     die("Connection failed: " . mysqli_connect_error());
// }
?>
<!DOCTYPE html>
<html>
  <head>
    <title>Movie List</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="design.css" type="text/css" rel="stylesheet">
    <script type="text/javascript">
        //create a javascript function named confirmation()
        function confirmation(){
            return confirm("Do you want to delete this movie?");
        }
    </script>
    <style> 
        table { 
            width: 100%; 
            border-collapse: collapse; 
        } 
        table, th, td { 
            border: 1px solid #ddd; 
        } 
        td { 
            padding: 6px; 
            text-align: center;
        } 
        th { 
            background-color:rgb(171, 190, 255);
            padding: 12px;
            text-align: center;
        } 
        tr:nth-child(even) { 
            background-color: #f9f9f9; 
        } 
        tr:hover { 
            background-color: #f1f1f1; 
        } 
        .btn { 
            padding: 8px 12px; 
            margin: 4px; 
            border: none; 
            background-color: #4CAF50; 
            color: white; 
            text-decoration: none; 
            cursor: pointer; 
        } 
        .btn:hover { 
            background-color: #45a049; 
        } 
        .btn-edit { 
            background-color: #ffa500; 
        } 
        .btn-edit:hover { 
            background-color: #e69500; 
        } 
        .btn-delete { 
            background-color: #f44336; 
        } 
        .btn-delete:hover { 
            background-color: #d32f2f; 
        } 
    </style>
  </head>

  <body>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="jumbotron">
                    <div id="wrapper">
                        <div id="left">
                            <?php include("menu1.php"); ?>
                        </div>
                        
                        <div id="right">
                            <h2>List of Movies</h2>
                            <table border="1">
                                <tr>
                                    <th>Movie ID</th>
                                    <th>Movie Title</th>
                                    <th>Movie Ticket Price</th>
                                    <th colspan="3">Action</th>
                                </tr>
                                
                                <?php
                                $result = $connect->query("SELECT * FROM movie");    
                                $count = $result->num_rows; //used to count number of rows
                                
                                while($row = $result->fetch_assoc())
                                {
                                ?>            
                                <tr>
                                    <td><?php echo $row["movie_id"]; ?></td>
                                    <td><?php echo $row["movie_title"]; ?></td>
                                    <td><?php echo $row["movie_ticket_price"]; ?></td>
                                    <td><a class="btn" href="movie_detail.php?view&movid=<?php echo $row['movie_id']; ?>">More Details</a></td>
                                    <td><a class="btn btn-edit" href="movie_edit.php?edit&movid=<?php echo $row['movie_id']; ?>">Edit</a></td>
                                    <td><a class="btn btn-delete" href="movie_list.php?del&movid=<?php echo $row['movie_id']; ?>" onclick="return confirmation();">Delete</a></td>
                                </tr>
                                <?php
                                }
                                ?>
                            </table>
                            <p>Number of records: <?php echo $count; ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/scripts.js"></script>
    </body>
</html>

<?php
if (isset($_REQUEST["del"])) {
    $movid = $_REQUEST["movid"];
    $stmt = $connect->prepare("DELETE FROM movie WHERE movie_id = ?");
    $stmt->bind_param("i", $movid);
    
    if ($stmt->execute()) {
        header("Location: movie_list.php"); // Refresh the page
    } else {
        echo '<script type="text/javascript">alert("Error deleting movie: ' . $stmt->error . '");</script>';
    }
    $stmt->close();
}

$connect->close();
?>
