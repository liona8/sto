<?php 
define('DB_SERVER', 'project-db.c3n9lymf1cu3.us-east-1.rds.amazonaws.com');
define('DB_USERNAME', 'main');
define('DB_PASSWORD', 'project-password');
define('DB_DATABASE', 'project');

$connect = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD);
if (mysqli_connect_errno())
    echo "Failed to connect to MySQL: " . mysqli_connect_error();

// Select the database
$database = mysqli_select_db($connect, DB_DATABASE);

// Check if there are tables in the database
$result = mysqli_query($connect, "SHOW TABLES");
if (mysqli_num_rows($result) == 0) {
    // No tables found, import the SQL file
    // $command = "mysql -u " . DB_USERNAME . " -p" . DB_PASSWORD . " -h " . DB_SERVER . " " . DB_DATABASE . " < cinema.sql";
    // exec($command, $output, $retval);
    if ($retval != 0) {
        echo "Failed to import tables: " . implode("\n", $output);
    } else {
        // echo "Tables imported successfully!";
    }
} else {
    // echo "Tables already exist in the database.";
}

?>
