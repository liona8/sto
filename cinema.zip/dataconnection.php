<?php

$connect= mysqli_connect("localhost","root","","cinema");// fill out database name

?>
