<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include('rds.conf.php');

// Connect to the database using mysqli
$connect = mysqli_connect($RDS_URL, $RDS_user, $RDS_pwd, $RDS_DB);
if (!$connect) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
<!DOCTYPE html>
<html>
  <head>
    <title>AWS Technical Essentials v4.1 - Add New Movie</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="design.css" type="text/css" rel="stylesheet" />
    <style>
        .btn{
            padding: 8px 12px; 
            margin: 4px; 
            border: none; 
            background-color: #008CBA; 
            color: white; 
            text-decoration: none; 
            cursor: pointer;
        }
        .btn:hover{
            background-color: #007B9E;
        }
    </style>
  </head>

  <body>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <?php include('menu.php'); ?>
                <div class="jumbotron">
                    <div id="wrapper">
                        <div id="left">
                            <?php include("menu1.php"); ?>
                        </div>
                        
                        <div id="right">
                            <h2>Insert New Movie</h2>
                            <form name="addfrm" method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
                                <p><label>Title:</label><input type="text" name="mov_title" size="80"></p>
                                <p><label>Ticket Price:</label><input type="text" name="mov_price" size="10"></p>
                                <p><label>Summary:</label><textarea cols="60" rows="4" name="mov_summary"></textarea></p>
                                <p><label>Release Date:</label><input type="date" name="mov_release"></p>
                                <p><input class="btn" type="submit" name="savebtn" value="SAVE MOVIE"></p>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/scripts.js"></script>
    </body>
</html>
<?php
if(isset($_POST["savebtn"])) {
    $mtitle = $_POST["mov_title"];      
    $mprice = $_POST["mov_price"];      
    $msummary = $_POST["mov_summary"];      
    $mrelease = $_POST["mov_release"];      

    $stmt = $connect->prepare("INSERT INTO movie (movie_title, movie_ticket_price, movie_summary, movie_release_date) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $mtitle, $mprice, $msummary, $mrelease);
    
    if ($stmt->execute()) {
        echo '<script type="text/javascript">alert("' . $mtitle . ' saved.");</script>';
    } else {
        echo '<script type="text/javascript">alert("Error saving movie: ' . $stmt->error . '");</script>';
    }
    $stmt->close();
}

$connect->close();
?>