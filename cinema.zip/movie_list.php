<?php

include('rds.conf.php');

// Connect to the RDS database using mysqli
$connect = new mysqli($RDS_URL, $RDS_user, $RDS_pwd, $RDS_DB);

if ($connect->connect_error) {
    die("Connection failed: " . $connect->connect_error);
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Movie List</title>
    <link href="design.css" type="text/css" rel="stylesheet" />
    <script type="text/javascript">
        //create a javascript function named confirmation()
        function confirmation(){
            return confirm("Do you want to delete this movie?");
        }
    </script>
</head>
<body>
    <div id="wrapper">
        <div id="left">
            <?php include("menu1.php"); ?>
        </div>
        
        <div id="right">
            <h1>List of Movies</h1>
            <table border="1">
                <tr>
                    <th>Movie ID</th>
                    <th>Movie Title</th>
                    <th>Movie Ticket Price</th>
                    <th colspan="3">Action</th>
                </tr>
                
                <?php
                $result = $connect->query("SELECT * FROM movie");    
                $count = $result->num_rows; //used to count number of rows
                
                while($row = $result->fetch_assoc())
                {
                ?>            
                <tr>
                    <td><?php echo $row["movie_id"]; ?></td>
                    <td><?php echo $row["movie_title"]; ?></td>
                    <td><?php echo $row["movie_ticket_price"]; ?></td>
                    <td><a href="movie_detail.php?view&movid=<?php echo $row['movie_id']; ?>">More Details</a></td>
                    <td><a href="movie_edit.php?edit&movid=<?php echo $row['movie_id']; ?>">Edit</a></td>
                    <td><a href="movie_list.php?del&movid=<?php echo $row['movie_id']; ?>" onclick="return confirmation();">Delete</a></td>
                </tr>
                <?php
                }
                ?>
            </table>
            <p>Number of records: <?php echo $count; ?></p>
        </div>
    </div>
</body>
</html>

<?php
if (isset($_REQUEST["del"])) {
    $movid = $_REQUEST["movid"];
    $stmt = $connect->prepare("DELETE FROM movie WHERE movie_id = ?");
    $stmt->bind_param("i", $movid);
    
    if ($stmt->execute()) {
        header("Location: movie_list.php"); // Refresh the page
    } else {
        echo '<script type="text/javascript">alert("Error deleting movie: ' . $stmt->error . '");</script>';
    }
    $stmt->close();
}

$connect->close();
?>
