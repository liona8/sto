<?php

include('rds.conf.php');

// Connect to the RDS database using mysqli
$connect = new mysqli($RDS_URL, $RDS_user, $RDS_pwd, $RDS_DB);

if ($connect->connect_error) {
    die("Connection failed: " . $connect->connect_error);
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit a Movie</title>
    <link href="design.css" type="text/css" rel="stylesheet" />
</head>
<body>
    <?php include('menu1.php'); ?>
    <div id="wrapper">
        <div id="left">
            <?php include("menu1.php"); ?>
        </div>
        
        <div id="right">
            <?php
            if (isset($_GET["edit"])) {
                $movid = $_GET["movid"];
                $stmt = $connect->prepare("SELECT * FROM movie WHERE movie_id = ?");
                $stmt->bind_param("i", $movid);
                $stmt->execute();
                $result = $stmt->get_result();
                $row = $result->fetch_assoc();

                if ($row) {
                    ?>
                    <h1>Edit a Movie</h1>
                    <form name="addfrm" method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
                        <p>Title:<input type="text" name="mov_title" size="80" value="<?php echo $row['movie_title']; ?>"></p>
                        <p>Ticket Price:<input type="text" name="mov_price" size="10" value="<?php echo $row['movie_ticket_price']; ?>"></p>
                        <p>Summary:<textarea cols="60" rows="4" name="mov_summary"><?php echo $row['movie_summary']; ?></textarea></p>
                        <p>Release Date:<input type="date" name="mov_release" value="<?php echo $row['movie_release_date']; ?>"></p>
                        <p><input type="submit" name="savebtn" value="UPDATE MOVIE"></p>
                    </form>
                    <?php
                } else {
                    echo "No movie found with that ID.";
                }
                $stmt->close();
            }
            ?>
        </div>
    </div>
</body>
</html>

<?php
if (isset($_POST["savebtn"])) {
    $mtitle = $_POST["mov_title"];
    $mprice = $_POST["mov_price"];
    $msummary = $_POST["mov_summary"];
    $mrelease = $_POST["mov_release"];
    $movid = $_GET["movid"];

    $stmt = $connect->prepare("UPDATE movie SET movie_title = ?, movie_ticket_price = ?, movie_summary = ?, movie_release_date = ? WHERE movie_id = ?");
    $stmt->bind_param("ssssi", $mtitle, $mprice, $msummary, $mrelease, $movid);
    
    if ($stmt->execute()) {
        echo '<script type="text/javascript">alert("Movie Updated");</script>';
        header("refresh:0.5; url=movie_list.php");
    } else {
        echo '<script type="text/javascript">alert("Error updating movie: ' . $stmt->error . '");</script>';
    }
    $stmt->close();
}

$connect->close();
?>
